# plugin.video.sling
Sling TV Add-On for Kodi

![](https://github.com/d21spike/plugin.video.sling/blob/master/resources/images/icon.png?raw=true)

![Build Status](https://img.shields.io/badge/Build-Beta-orange)
![License](https://img.shields.io/badge/License-GPL--3.0--only-success.svg)
![Kodi Version](https://img.shields.io/badge/Kodi-Leia%2B-brightgreen)
![Contributors](https://img.shields.io/badge/Contributors-d21spike%2C%20eracknaphobia-darkgray)

## Links

* [Sling TV](https://www.sling.com/)
* [Support Thread](https://forum.kodi.tv/showthread.php?tid=351048)
* [Wiki](https://github.com/d21spike/plugin.video.sling/wiki)
* [Kodi Wiki](https://kodi.wiki/view/Main_Page)
