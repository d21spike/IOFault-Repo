import xbmcaddon
from resources.lib.globals import *
from resources.lib.service.slinger import Slinger

if USE_SLINGER:
    Slinger()
