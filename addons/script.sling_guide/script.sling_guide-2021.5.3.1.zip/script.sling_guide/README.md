# script.sling_guide
A supplemental guide to the plugin.video.sling add-on
